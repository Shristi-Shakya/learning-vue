<template>
	<div>
		
		<my-product
		v-for="product in product"
		:key="product.id"
		@delete-product = "deleteProduct(product)"
		:authenticatedUser = "authenticatedUser"
		:product = "product">
		</my-product>
		<!-- : to pass object otherwise it will read as string -->
		
	</div>
	
</template>

<script type="text/javascript">
	import Product from './Product.vue'
	//import swal from 'sweetalert'

	export default {
		data(){
			return {
				product: [],
				//test: 'I am a string' this is hardcoded so displayed bt authenticatedUser will not because it is not hard coded
			}
		},

		computed: {
			authenticatedUser(){
				return this.$auth.getAuthenticatedUser()
			}
		},

		components: {
			'my-product': Product
		},

		created(){
			this.$http.get('api/product')
			.then(response => {
				this.product = response.body
			})
		},

		// methods: {
		// 	deleteProduct (product){
		// 		swal({
		// 		  title: "Are you sure?",
		// 		  text: "You will not be able to recover this product file!",
		// 		  type: "warning",
		// 		  showCancelButton: true,
		// 		  confirmButtonColor: "#DD6B55",
		// 		  confirmButtonText: "Yes, delete it!",
		// 		  closeOnConfirm: false
		// 		},

		// 		function(){
		// 			this.$http.delete('api/product/' + product.id)
		// 			.then(response => {
		// 				let index = this.product.indexOf(product)
		// 				this.product.splice(index, 1)
						
		// 				swal("Deleted!", "Your product has been deleted.", "success");
		// 			})
				  
		// 		}.bind(this)
		// 		);
		// 	}
		// }


	}
</script>