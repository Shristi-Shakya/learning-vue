<template>
	<div class="row">
		<div class="col-md-4">
			<div class="thumbnail">
				<div class="caption">
					{{ product.user_id}}

					<h3> {{ product.name }} </h3>
					<p> {{ product.price }} </p>
					<hr>
					<p>
						<a href="#" class="btn btn-default"> Wish List</a>
						<a href="#" class="btn btn-success"> Buy there</a>
					</p>
					<hr>
					<p
						v-if="product.user_id == authenticatedUser.id"
					>
						<a href="#" class="btn btn-danger" role="button" @click="$emit('delete-product')">
							Delete
							</a>
					</p>
				</div>
			</div>
		</div>		
	</div>
	
</template>

<script type="text/javascript">


	export default{
		props: ['product', 'authenticatedUser'],


	}
</script>