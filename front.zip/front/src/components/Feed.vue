<template>
	<div>
		<h1>Feed</h1>

		<!-- <my-products>
		</my-products> -->

	</div>
	
</template>

<script type="text/javascript">
	 //import Products from './product/Products.vue'

	export default {
		// components: {
		// 	'my-products' : Products
		// }

		data (){
			return {
				products: []
			}
		},

		created(){
			this.$http.get('api/product')
		}
	}
</script>

