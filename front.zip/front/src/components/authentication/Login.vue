<!-- these are componenets-->

<template> 
	<div>
	<form class="form-signin">
	    <h2 class="form-signin-heading">Please sign in</h2>
	    <label for="inputEmail" class="sr-only">Email address</label>
	    	<input type="email" id="inputEmail" class="form-control" placeholder="Email address" required autofocus v-model="email">
	    <label for="inputPassword" class="sr-only">Password</label>
	    		<input type="password" id="inputPassword" class="form-control" placeholder="Password" required v-model="password">
	    <div class="checkbox">
	      <label>
	        <input type="checkbox" value="remember-me"> Remember me
	      </label>
	    </div>
	    <button  @click="login" class="btn btn-lg btn-primary btn-block" type="submit">Sign in</button>
	</form>
	
</div>
</template>
<script type="text/javascript">
	export default{
		data(){
			return{
				email: '',
				password: ''
			}
		},
		methods: {
			// test(){
			// 		this.$http.get("http://localhost/landv/back/api/test")
			// 		.then(function(response){
			// 			console.log(response)
			// 		})
			// 	},
			login (){

				var data = {
					client_id: 10,
					client_secret : 'SYe6JKlFpDmMfR8Zy1F4rbG6x86BLuAHtqlbmEwm',
					grant_type: 'password',
					username: this.email,
					password: this.password
				}
				this.$http.post("oauth/token", data)
					.then(response => {
						//console.log(response)
						this.$auth.setToken( response.body.access_token,  response.body.expires_in+Date.now() )

						this.$router.push("/feed")
					})
				// .then(function (response) {
				// 	console.log(response)
				// })
			}
		}
	}
</script>
<style type="text/css"></style>